<?php

/* THIS METHOD IS USED FOR AUTOMATICALLY LOADING THE CLASSES*/

spl_autoload_register('myAutoLoader');
function myAutoLoader($className){
    $path = "Classes/";
    $extension = ".class.php";
    $fullPath = $path . $className . $extension;
    include_once $fullPath;
}
 ?>