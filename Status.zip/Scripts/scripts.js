// var prevScrollpos = window.pageYOffset;
// window.onscroll = function() {
// var currentScrollPos = window.pageYOffset;
//   if (prevScrollpos > currentScrollPos) {    
//     document.getElementById("logo").style.top   = "0px";
//   } else {
//     document.getElementById("logo").style.top   = "-120px";
//   }
//   prevScrollpos = currentScrollPos;
// }