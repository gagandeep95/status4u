<?php
include_once('Layouts/Master.layouts.php');

$_cat = $_GET['category'];
$_status_id = ''; 
if(isset($_cat)){
	  $_obj   = new StatusView();
    $rows = $_obj->showStatus($_cat);
?>

<section class="col-md-9" >
		<br>
		<nav aria-label="breadcrumb ">
  			<ol class="breadcrumb" >
    			  <li class="breadcrumb-item "><a href="#" style="color:#e74c3c">Categories</a></li>
    			  <li class="breadcrumb-item"><a href="#" style="color:#e74c3c"><?php echo ucfirst($_cat) ?></a></li>
  			</ol>
		</nav>
    <div id="load_status">
    <?php  
    foreach($rows as $row){
        echo '<div class="card"><div class="card-body"><i class="fa fa-quote-left"></i>  '.$row['status'].'</div></div>';
        $_status_id = $row['id'];
    }
    echo'<div id="remove_row">  
            <button type="button" name="btn_more" data-sid="'.$_status_id.'" id="btn_more" class="btn btn-success form-control"><i class="fa fa-spinner fa-lg"></i> Load More Data</button>  
          </div> '; 
  }
?>
</div><br>
<div id="load_status_message"></div>
		
</section>
</div>
</div>



<?php
	include_once('Layouts/Footer.layouts.php');
?>


<script>
  $(document).ready(function(){  
      $(document).on('click', '#btn_more', function(){  
           var last_status_id = $(this).data("sid"); 
           
           var cat            = '<?php  echo $_cat ?>';
           $('#btn_more').html("Loading...");

           $.ajax({  
                url:"fetch_status.php",  
                method:"POST",  
                data:{last_status_id:last_status_id,
                      cat:cat},  
                dataType:"text",  
                success:function(data)  
                {  
                     if(data != '')  
                     {  
                          $('#remove_row').remove();  
                          $('#load_status').append(data);  
                     }  
                     else  
                     {  
                          $('#btn_more').html("No Data");  
                     }  
                }  
           });  
      });  
 });  
 </script>

</script>