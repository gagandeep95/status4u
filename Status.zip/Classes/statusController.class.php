<?php

class StatusController extends status{
 
 	public function addQuote($status,$cat){
 		$results = $this->setStatus($status,$cat);
 		return $results;
 	}

  public function updateQuote($id,$status,$cat){
    $results = $this->updateStatus($id,$status,$cat);
    return $results;
  }
  

 	public function delStatus($id){
 		$results = $this->deleteStatus($id);
 				return $results;
 		}
 	}



