 <?php
 class StatusView extends Status{

    public function showAllStatus(){
 		$results = $this->getAllStatus();
 		return $results;
 	} 
 	public function showStatus($category){
 		$results = $this->getStatus_OrderByCategory($category);
 		return $results;
 	}
 	public function showStatus_OrderByCateory_Limit($_cat,$last_status_id){
 		$results = $this->getStatus_OrderByCategory_Limit($_cat,$last_status_id);		
 		return $results;
 		
 	}
 	public function showStatus_OrderById($id){
 		$results = $this->getStatus_OrderById($id);
 		return $results;
 	} 	

 }

