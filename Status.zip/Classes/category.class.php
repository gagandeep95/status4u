<?php
	class Category extends Db{


		protected function getAllCategories(){
			$sql 	= "SELECT * FROM categories ORDER BY id DESC";
			$stmt	= $this->connect()->query($sql);			
			$results = $stmt->fetchAll();
			return $results;
		}

		protected function setCategory($category){
			$sql  = "INSERT INTO categories(category)VALUES(?)";
			$stmt = $this->connect()->prepare($sql);
			$results = $stmt->execute([$category]);
			return $results;			
		}

		protected function deleteCategory($id){
			$sql  = "DELETE FROM categories WHERE id = ?";
			$stmt = $this->connect()->prepare($sql);
			$results = $stmt->execute([$id]);
			return $results;	
		}
	}

?>