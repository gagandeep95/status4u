<?php

class Loginview extends Login{

	public function showAdmin(){
		$results = $this->getAdmin();
        return $results;
	}	
}

