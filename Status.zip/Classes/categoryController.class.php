<?php

class CategoryController extends Category{
 
 	public function addCategory($cat){
 		$results = $this->setCategory($cat);
 	}

 	public function delCategory($id){
 		$results = $this->deleteCategory($id);
 				
 		}
 	}



