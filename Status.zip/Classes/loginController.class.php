<?php
class LoginController extends Login{
	public function auth($username,$password){
		$results = $this->getAdmin();
		if(($results['username'] == $username) && ($results['password'] == $password)){
			$_SESSION['username'] = $results['username'];
			header("location:index.php");	    	
	}
	else{
		echo "<div class='alert alert-danger text-center'>
  				<strong>OOPS!</strong> You are not authorized person 
			  </div>";
	}
	}

}
