<?php
	class Status extends Db{

		protected function getAllStatus(){
			$sql 	= "SELECT * FROM quotes ORDER BY id DESC";
			$stmt	= $this->connect()->query($sql);			
			$results = $stmt->fetchAll();
			return $results;
		}
		
		protected function getStatus_OrderByCategory($category){
			$sql 	= "SELECT * FROM quotes WHERE  category = ? ORDER BY id  LIMIT 10 ";
			$stmt	= $this->connect()->prepare($sql);
			$stmt->execute([$category]);
			$results = $stmt->fetchAll();
			return $results;
		}

		protected function getStatus_OrderByCategory_Limit($category,$last_status_id){
			$sql 	= "SELECT * FROM quotes  WHERE  id > ?  AND category = ?  ORDER BY id  LIMIT 10";
			$stmt	= $this->connect()->prepare($sql);
			$stmt->execute([$last_status_id,$category]);
            // echo $number_of_rows;
            $results = $stmt->fetchAll();			
	     	$number_of_rows = count($results);
            if($number_of_rows > 0){
            	return $results;	
            } 
            else{
               return 0;
            }

             // return $results;
   //         		}
}

		protected function getStatus_OrderById($id){
			$sql 	= "SELECT * FROM quotes WHERE id = ?";
			$stmt	= $this->connect()->prepare($sql);
			$stmt->execute([$id]);
			$results = $stmt->fetch();
			return $results;
		}


		protected function setStatus($quote,$category){
			$sql  = "INSERT INTO quotes(status,category)VALUES(?,?)";
			$stmt = $this->connect()->prepare($sql);
			$results = $stmt->execute([$quote,$category]);
			return $results;
		}

		protected function updateStatus($id,$quote,$category){
			$sql  = "UPDATE quotes SET status = ? ,category = ? WHERE  id = ?";
			$stmt = $this->connect()->prepare($sql);
			$results = $stmt->execute([$quote,$category,$id]);
		 	return $results;			
		}

		protected function deleteStatus($id){
			$sql  = "DELETE FROM quotes WHERE id = ?";
			$stmt = $this->connect()->prepare($sql);
			$results = $stmt->execute([$id]);
			return $results;	
		}
	}

?>