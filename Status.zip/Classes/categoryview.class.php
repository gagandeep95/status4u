 <?php
 class CategoryView extends Category{

    public function showAllCategories(){
 		$results = $this->getAllCategories();
 		return $results;
 	} 
 }

