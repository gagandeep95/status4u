<?php

class Login extends Db{
	protected function getAdmin(){
		$sql  = "SELECT * FROM admin WHERE username = ? AND password = ?";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute(['admin','admin']);
		$results = $stmt->fetch();
		return $results;
	}


}
