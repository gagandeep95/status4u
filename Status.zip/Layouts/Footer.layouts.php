       

<footer class="row text-secondary py-3" style="background-color: #000;">
  
    <div class="col-md-4  footerBrand"><i class="fas fa-copyright ml-2"></i> 2020 SharesStatus.com</div>
    <div class="col-md-4"> </div>
    <div class="footerMenu col-md-4"> 
        <a href="#" class="mx-2 text-decoration-none text-secondary">About Us</a>/
        <a href="#" class="mx-2 text-decoration-none text-secondary">Privacy Policy</a>/
        <a href="#" class="mx-2 text-decoration-none text-secondary">Terms & Conditions</a>
    </div>
     </div>
</footer>
                                    <!-- SCRIPTS -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="Scripts/scripts.js"></script>
      <script src='https://kit.fontawesome.com/a076d05399.js'></script>
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
     
</body>
</html>
