<?php
include_once('autoloader.layout.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  		<title>Status Shares</title>
  		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1" />  
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />
      <link rel="stylesheet" href="css/hover-min.css" />
      <link rel="stylesheet" href="css/styles.css" />
      <style>        
      .row{
          margin-left: 0px!important;
          margin-right: 0px!important;
      }
      </style>
</head>
<body>
                                        <!-- LOGO SECTION START  -->
      <div class="shadow-lg p-3 mb-3 bg-white text-center" id="logo" >
          <a class="text-decoration-none" href="/Status">STATUS4U</a>      
      </div>	
                                        <!-- LOGO SECTION END  -->                                        
                                        
                                        <!-- WRAPPER ELEMENT START -->
<div class="container-fluid" id="wrapper" >
    <div class="row">                                         
    


                    <!-- SIDEBAR SECTION START (ALL CATEGORIES) -->

    <aside class="col-lg-3 list-menu">      
        <ul class="nav flex-column">
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=attitude"><i class="fa fa-atom" ></i> ATTITUDE</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=romantic"><i class="fa fa-grin-hearts" ></i> ROMANTIC</a>
          </li>          
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=sad"><i class="fa fa-sad-cry" ></i> SAD</a>
          </li>     
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=love"><i class="fa fa-heart" ></i> LOVE</a>
          </li>          
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=funny"><i class="fa fa-laugh-wink" ></i> FUNNY</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="category.php?category=motivational"><i class="fa fa-dumbbell" ></i> MOTIVATIONAL</a>
          </li>    
        </ul>
    </aside>
                    <!-- CLOSING SIDEBAR SECTION-->
