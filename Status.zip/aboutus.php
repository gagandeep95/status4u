<?php
	require_once('Layouts/Master.layouts.php');
?>

<div class="container-fluid">
	<div class="row" >
		<article class="about-content text-secondary">
			<h2>ABOUT US	</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore voluptatibus explicabo neque, quae suscipit vero commodi voluptate animi earum impedit, ut odit qui enim omnis aliquam aut obcaecati rem architecto.
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit, placeat cum error assumenda iste corporis esse voluptatibus cupiditate ad ex veniam earum nam fugiat fugit rem modi eveniet soluta similique?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam porro nisi non corporis minima ut voluptatibus at dolores laboriosam nobis a, quia, aperiam, consectetur officia ipsum fugit provident aut repellendus.</p>
		</article>
	</div>
</div>	


<div class="container">
 	<h2 class="text-center">MEET OUR TEAM</h2>
 	<br>
  	<div class="row team" >
    	<div class="col-sm-4" >
    		<img src="Images/gg.png" class="img-rounded img-responsive" style="width:100%" alt="">		
    	</div>
    	<div class="col-sm-8 teamInfo text-secondary">
    		<h4>GAGANDEEP GURU</h4>
    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis quam facere beatae itaque tenetur, magnam, possimus labore provident obcaecati quia! Quam unde, saepe velit. Necessitatibus repellendus atque deserunt officiis delectus!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, doloremque minus soluta maxime atque mollitia ipsa voluptates at, tempora maiores sequi odit doloribus vel aperiam nemo pariatur, nostrum eos quis?</p>
    	</div>
  	</div>
</div>

<br><br>

<div class="container">
  	<div class="row team" >
    	<div class="col-sm-8 teamInfo text-secondary">
    		<h4>SAKSHI CHUMBER</h4>
    		<hr>	
    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis quam facere beatae itaque tenetur, magnam, possimus labore provident obcaecati quia! Quam unde, saepe velit. Necessitatibus repellendus atque deserunt officiis delectus!Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit, doloremque minus soluta maxime atque mollitia ipsa voluptates at, tempora maiores sequi odit doloribus vel aperiam nemo pariatur, nostrum eos quis?</p>
    	</div>
    	    	<div class="col-sm-4" >
    		<img src="Images/gg.png" class="img-rounded img-responsive" style="width:100%" alt="">		
    	</div>

  	</div>
</div>



<br><br><br><br>
<?php
 include_once('Layouts/Footer.layouts.php');
?>