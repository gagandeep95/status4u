<?php
include_once('autoloader.layout.php');

$output = '';  
$status_id = '';  
sleep(1);
	    $last_status_id = $_POST['last_status_id'];
      $_cat   = $_POST['cat'];

      $obj = new StatusView();
      $results = $obj->showStatus_OrderByCateory_Limit($_cat,$last_status_id);
      if($results == 0){
  echo '<button type="button"   class="btn btn-success form-control">No More Data</button>';
 
      }
      else{
        foreach($results as $result){
            $status_id = $result['id'];   
            echo '<div class="card">
             <div class="card-body">'.$result['status'].'</div>
               </div>';
        }
        echo '<div id="remove_row">  
            <button type="button" name="btn_more" data-sid="'. $status_id .'" id="btn_more" class="btn btn-success form-control"><i class="fa fa-spinner fa-lg"></i> Load More Data</button></td>  
               </tr></tbody>  
     ';  
     }

?>