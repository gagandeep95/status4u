										
										<!-- ADDING MASTER PAGE  -->
<?php include_once('Layouts/Master.layouts.php');?>




                                      <!-- STARTING THUMBNAILS SECTION -->

		<section class="thumbnails row col-lg-9 p-5">
			<a href="category.php?category=motivational" id="motivational" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-2 shadow text-decoration-none">
				<h5 class="category_name text-center" >MOTIVATIONAL</h5>
			</a>

			<a href="category.php?category=attitude"  id="attitude" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-2 shadow text-decoration-none">
				<h5 class="category_name text-center" >ATTITUDE</h5>
			</a>

			<a href="category.php?category=funny" id="funny" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-2 shadow text-decoration-none">
				<h5 class="category_name text-center" >FUNNY</h5>
			</a>

			<a href="category.php?category=love" id="love" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-3 shadow text-decoration-none">
				<h5 class="category_name text-center" >LOVE</h5>
			</a>
			<a href="category.php?category=sad" id="sad" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-3 shadow text-decoration-none">
				<h5 class="category_name text-center" >SAD</h5>
			</a>

			<a href="category.php?category=motivational" id="romantic" class="hvr-bob thumbnail_block col-lg-3 ml-5 mb-3 shadow text-decoration-none">
				<h5 class="category_name text-center" >ROMANTIC</h5>
			</a>
		</section> 	

</div>
	</div>
</div>

</body>
</html>

										 <!-- SCRIPTS  -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="Scripts/scripts.js"></script>
      <script src='https://kit.fontawesome.com/a076d05399.js'></script>