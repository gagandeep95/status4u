<?php
include_once('../autoloader.layout.php');  
$auth_obj = new Loginview();
$row = $auth_obj->showAdmin();
if(isset($_SESSION['username']) != $row['username']){
  header("location:login.php");
}
require_once('Layouts/Master.layouts.php');
?>

<br><br><br><br>

<div class="container">
  <div class="row">
  <div class="col-lg-4">
    <button type="submit" class="btn btn-danger" id="add" data-toggle="modal" data-target="#myModal">
    <i class="fa fa-plus-circle"></i> Quote
  </button>
  </div>
  <div id="message" class="col-lg-8">
    
  </div>
  </div>
  

<?php 

                              // FOR SHOWING ALL STATUS 
     
     $categories_obj = new categoryview();
     $cat_rows    = $categories_obj->showAllCategories(); 

?>



  
  <br>          
  <div id="status_details">
      
  </div>

  	







<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <!-- <h4 class="modal-title text-center"><i class="fa fa-plus-circle"></i> Quote</h4> -->
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" id="insert-form">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
              <span class="input-group-text "><i class="fa fa-plus-square"></i></span>
          </div>
          <input type="text" class="form-control" id="quote" name="quote" placeholder="Write a Quote !" required>
        </div>
        <div class="form-group">
          <select class="form-control" name="category" id="category">
            <?php 
                 foreach($cat_rows as $cat_row){ 
            ?>
                 
            <option><?php echo ucfirst($cat_row['category'])  ?></option>
            <?php  } ?>

          </select>
      </div>
      <input type="hidden" name="status_id" id="status_id" />
      <button type="submit"   name="insert" id="insert" value="Insert" class="form-control btn btn-danger">Insert</button>
    </form>
      </div>

    </div>
  </div>
</div>





<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      
      
<script>

$(document).ready(function(){

// $("#details").DataTable();
 
$('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert-form')[0].reset();  
});  





$(document).on("click",".edit_data", function(){
    var status_id = $(this).attr("id");        
    $.ajax({
        url:"fetch_status.php",
        method:"POST",
        data:{status_id:status_id},
        dataType:"json",
        success:function(data){
          $("#quote").val(data.status);
          $("#category").val(data.category);
          $("#status_id").val(data.id);
          $("#insert").val("Update");
          window.$("#myModal").modal("show");
        }
    });

});


// INSERT DATA
  $("#insert-form").on("submit",function(event){
    event.preventDefault(); 
    $.ajax({
      url:"insert_status.php",
      method:"POST",
      data:$('#insert-form').serialize(),
      beforeSend:function(){
        $("#insert").val("Inserting");
      },
      success:function(data){
           
        $("#insert-form")[0].reset();        
        $("#message").html(data);
        load_data(); 
        $("#myModal").modal("hide");
        
      }
    });
  });

// delete data

$(document).on("click",".delete_data", function(){
    var status_id = $(this).attr("id");    
    $.ajax({
        url:"deleteStatus.php",
        method:"POST",
        data:{status_id:status_id},
        success:function(data){
          $("#message").html(data);
          load_data();
        }
    });

});



// RETRIVE DATA

load_data();
function load_data(){
  var action = "Load";
  $.ajax({
    url:"selectStatus.php",
    method:"POST",
    data:{action:action},  
      success:function(data)  
      {  
        $('#status_details').html(data);
      }  
  });
}

});
</script>




