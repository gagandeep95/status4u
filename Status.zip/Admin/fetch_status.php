<?php
include_once('../autoloader.layout.php');
if(isset($_POST['status_id'])){
	$id = $_POST['status_id'];
	$obj = new StatusView();
	$results = $obj->showStatus_OrderById($id);
	echo json_encode($results);	 
}
?>