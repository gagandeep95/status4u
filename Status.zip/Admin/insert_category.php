<?php
include_once('../autoloader.layout.php');
if(!empty($_POST))
{
      $cat = stripslashes($_POST['category']); 

      $cat_obj = new CategoryController();
      $results =  $cat_obj->addCategory($cat);     
}
?>