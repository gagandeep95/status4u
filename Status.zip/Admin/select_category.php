<?php
include_once('../autoloader.layout.php');

if(isset($_POST['action']) == 'Load'){
 
$categories_obj = new categoryview();
$cat_rows    = $categories_obj->showAllCategories(); 

$output = '';
$output .= '<div class="table table-responsive"><table class="table table-bordered">
    	<thead>
      		<tr>
        		<th>ID</th>
        		<th>CATEGORY</th>
        		<th>DELETE</th>
      		</tr>
    	</thead>
    	<tbody>';
        foreach ($cat_rows as $row) {
     
$output .= '     		<tr>
        		<td>'.$row["id"].'</td>
        		<td>'.$row["category"].'</td>
        		<td><button type="button"  id="'.$row["id"].'"  class="btn btn-danger delete_data">DELETE</button></td>        		
      		</tr>';
          }
      		
$output .='    	</tbody>
  	</table></div>';
echo $output;
}  	