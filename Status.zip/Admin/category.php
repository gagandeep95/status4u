<?php
 include_once('../autoloader.layout.php');
    
  $auth_obj = new Loginview();
  $row = $auth_obj->showAdmin();
   if(isset($_SESSION['username']) != $row['username']){
      header("location:login.php");
  }
  require_once('Layouts/Master.layouts.php');
?>

<br><br><br><br>
<div class="container">
  	<h2>Quotes</h2>
  <!-- Button to Open the Modal -->
	<button type="button" id="add" class="btn btn-danger" data-toggle="modal" data-target="#myModal">
  	+ CATEGORY
	</button>

	<br><br>            
  
<div id="category_details"> 

</div>

</div>











<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title text-center">+CATEGORY</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form method="post" id="insert_category">
  			<div class="input-group mb-3">
    			<div class="input-group-prepend">
      				<span class="input-group-text">@</span>
    			</div>
    			<input type="text" class="form-control"  id="category" name="category" placeholder="Add a Category !">
  			</div>
			<button type="submit" name="insert" id="insert" class="form-control btn btn-danger">UPLOAD</button>
		</form>
      </div>

    </div>
  </div>
</div>


<!-- 
<?php
	// require_once('../Layouts/Footer.layouts.php');
?>
 -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
     

<script>

$(document).ready(function(){

// INSERTING CATEGORY

$("#insert_category").on('submit',function(event){
event.preventDefault();
$.ajax({
      url:"insert_category.php",
      method:"POST",
      data:$('#insert_category').serialize(),
      beforeSend:function(){
        $("#insert").val("Inserting");
      },
      success:function(data){
        $('#insert_category')[0].reset();        
        load_data();
        $('#myModal').modal("hide");
       
      }
    });
});

$(document).on('click','.delete_data',function(){
  var cat_id = $(this).attr("id");
$.ajax({
      url:"deleteCategory.php",
      method:"POST",
      data:{cat_id:cat_id},
      success:function(data){        
        load_data();
      }
    });
});



// RETRIVE DATA

load_data();
function load_data(){
  var action = "Load";
  $.ajax({
    url:"select_category.php",
    method:"POST",
    data:{action:action},  
      success:function(data)  
      {  
        $('#category_details').html(data);
      }  
  });
}

});


</script>