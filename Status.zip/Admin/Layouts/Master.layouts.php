<!DOCTYPE html>
<html lang="en">
<head>
  		<title>Status Shares</title>
  		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" />  
      <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/style.css" />	
                              <!-- SCRIPTS -->
      
      <style>
        .dataTables_filter {
          text-align: right;
          margin-left: 600px;
          margin-bottom: 20px;
        }
        .dataTables_paginate{
          margin-left: 500px;
        }
        @media only screen and (max-width: 768px){
          .dataTables_filter{            
          margin-left: 300px;
          }
           .dataTables_paginate{
          margin-left: 150px;
        }  
        }
        @media only screen and (max-width: 480px){
          .dataTables_filter{            
          margin-left: 0px;
          }
           .dataTables_paginate{
          margin-left: 50px;
        }  
        }
      </style>

</head>
<body>
   	<nav class="navbar navbar-expand-sm fixed-top bg-dark navbar-dark" id="navbar">
  			<!-- Brand -->
        <a class="navbar-brand" href="#">ShareStatus</a>

        					                  <!-- Toggler/collapsibe Button -->
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    			<span class="navbar-toggler-icon"></span>
  			</button>
							                 	   <!-- Navbar links -->
  			<div class="collapse navbar-collapse " id="collapsibleNavbar">
  				<ul class="navbar-nav ml-auto ">
    				<li class="nav-item"><a class="nav-link" href="index.php"><i class="fa fa-home"></i> DASHBOARD</a></li>
            <li class="nav-item"><a class="nav-link" href="category.php"><i class="fa fa-list"></i> CATEGORY</a></li>
    			  <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-envelope"></i> CONTACT</a></li>
          
          				                 <!-- Dropdown -->
    				<li class="nav-item dropdown">
      					<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"><i class="fa fa-user"></i> GURU</a>
      		      <div class="dropdown-menu">
        					 <a class="dropdown-item" href="logout.php">LOGOUT</a>        					
      					</div>
    				</li>
    			</ul>
  			</div>	
		</nav>



