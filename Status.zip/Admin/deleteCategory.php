<?php
include_once('../autoloader.layout.php');

if(isset($_POST['cat_id'])){
	
	$catId = $_POST['cat_id'];
	$delete_obj = new CategoryController();
	$delete_obj->delCategory($catId);

}

?>