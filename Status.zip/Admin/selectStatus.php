<?php
include_once('../autoloader.layout.php');
include_once('Layouts/Master.layouts.php');

if(isset($_POST['action']) == 'Load'){

$status_obj = new Statusview();
$rows       =  $status_obj->showAllStatus();
     
$categories_obj = new categoryview();
$cat_rows    = $categories_obj->showAllCategories(); 

$output = '';


$output .= '
            <table id="details"  class="table table-striped table-bordered">

    	<thead>
      		<tr>
        		<th>ID</th>
       		 	<th>STATUS</th>
        		<th>CATEGORY</th>
        		<th>CREATED_AT</th>
        		<th>EDIT</th>
        		<th>DELETE</th>
      		</tr>
    	</thead>
    	<tbody>';
        foreach ($rows as $row) {
     
$output .= '     		<tr>
        		<td>'.$row["id"].'</td>
        		<td>'.$row["status"].'</td>
        		<td>'.$row["category"].'</td>
        		<td>'.$row["created_at"].'</td>
        		<td><button type="button" class="btn btn-primary edit_data"   id="'.$row["id"].'" ><i class="fa fa-edit"></i></button></td>
        		<td><button type="button"  id="'.$row["id"].'"  class="btn btn-danger delete_data"><i class="fa fa-trash"></i></button></td>        		
      		</tr>';
          }
      		
$output .='    	</tbody>
  	</table>';
echo $output;
}  	


?>

<script>
  $(document).ready(function(){

$("#details").DataTable();
});
</script>

