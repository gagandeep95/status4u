<?php
include_once('../autoloader.layout.php');
if(!empty($_POST))
{
 $output = "";
 $quote = stripslashes($_POST['quote']);
 $cat 	= stripslashes($_POST['category']); 
 $status_obj = new StatusController();
 // $results = "";
if($_POST['status_id'] != ''){
	$id = $_POST['status_id'];
	$results = $status_obj->updateQuote($id,$quote,$cat); 	
	if($results == 1){
    	echo'<div class="alert alert-success alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>Success!</strong> <i class="fa fa-smile-wink"></i> Row updated successfully.
			</div>';
    }
    else{
    		echo'<div class="alert alert-danger alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>OOPS!</strong> Something went wrong.
			</div>';	
    }
}
else{
	$results =  $status_obj->addQuote($quote,$cat);
    if($results == 1){
    	echo'<div class="alert alert-success alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>Success!</strong> Row inserted successfully.
			</div>';
    }
    else{
    		echo'<div class="alert alert-danger alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>Oops!</strong> Something went wrong.
			</div>';	
    }
}
}
?>