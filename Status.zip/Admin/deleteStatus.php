<?php
include_once('../autoloader.layout.php');

if(isset($_POST['status_id'])){
	
	$statusId = $_POST['status_id'];
	$delete_obj = new StatusController();
	$results = $delete_obj->delStatus($statusId);
	if($results == 1){
    	echo'<div class="alert alert-success alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>Success!</strong> <i class="fa fa-smile-wink"></i> Row deleted successfully.
			</div>';
    }
    else{
    		echo'<div class="alert alert-danger alert-dismissible">
  				<button type="button" class="close" data-dismiss="alert">&times;</button>
  				<strong>OOPS!</strong> <i class="fa fa-surprise"></i> Something went wrong.
			</div>';	
    }
}

?>